export class User {
  id:number;
  vorname: string;
  nachname: string;
  email: string;
}
